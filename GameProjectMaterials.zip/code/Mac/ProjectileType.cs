﻿using System;

namespace GameProject
{
	/// <summary>
	/// An enumeration of the projectile types
	/// </summary>
	public enum ProjectileType
	{
		FrenchFries,
		TeddyBear
	}
}
